// import 'package:flutter/material.dart';
// import 'package:geolocator/geolocator.dart';

// void main() {
//   runApp(const MyApp());
// }

// class MyApp extends StatelessWidget {
//   const MyApp({Key? key}) : super(key: key);

//   // This widget is the root of your application.
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Flutter Demo',
//       theme: ThemeData(
//         primarySwatch: Colors.blue,
//       ),
//       home: const locationn(title: 'Flutter Demo Home Page'),
//     );
//   }
// }

// class locationn extends StatefulWidget {
//   const locationn({Key? key, required this.title}) : super(key: key);

//   final String title;

//   @override
//   State<locationn> createState() => _MyHomePageState();
// }

// class _MyHomePageState extends State<locationn> {

//   Position? _position;

//   void _getCurrentLocation() async {
//     Position position = await _determinePosition();
//     setState(() {
//       _position = position;
//     });
//   }

//   Future<Position> _determinePosition() async {
//     LocationPermission permission;

//     permission = await Geolocator.checkPermission();

//     if(permission == LocationPermission.denied) {
//       permission = await Geolocator.requestPermission();
//       if(permission == LocationPermission.denied) {
//         return Future.error('Location Permissions are denied');
//       }
//     }

//     return await Geolocator.getCurrentPosition();
//   }

//   @override
//   Widget build(BuildContext context) {
//     // This method is rerun every time setState is called, for instance as done
//     // by the _incrementCounter method above.
//     //
//     // The Flutter framework has been optimized to make rerunning build methods
//     // fast, so that you can just rebuild anything that needs updating rather
//     // than having to individually change instances of widgets.
//     return Scaffold(
//       appBar: AppBar(
//         // Here we take the value from the MyHomePage object that was created by
//         // the App.build method, and use it to set our appbar title.
//         title: Text("Geolocation App"),
//       ),
//       body: Center(
//         child: _position != null ? Text('Current Location: ' + _position.toString()) : Text('No Location Data'),
//       ),
//       floatingActionButton: FloatingActionButton(
//         onPressed: _getCurrentLocation,
//         tooltip: 'Increment',
//         child: const Icon(Icons.add),
//       ), // This trailing comma makes auto-formatting nicer for build methods.
//     );
//   }
// }




import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const locationn(title: 'Flutter Demo Home Page'),
    );
  }
}

class locationn extends StatefulWidget {
  const locationn({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<locationn> createState() => _LocationAppState();
}

class _LocationAppState extends State<locationn> {
  Position? _position;
  String? _error;

  void _getCurrentLocation() async {
    try {
      Position position = await _determinePosition();
      setState(() {
        _position = position;
        _error = null;
      });
    } catch (e) {
      setState(() {
        _position = null;
        _error = 'Error: $e';
      });
    }
  }

  Future<Position> _determinePosition() async {
    LocationPermission permission;

    permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error('Location Permissions are denied');
      }
    }

    return await Geolocator.getCurrentPosition();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Geolocation App"),
      ),
      body: Center(
        child: _error != null
            ? Text('Error: $_error')
            : _position != null
                ? Text('Current Location: ' + _position.toString())
                : const Text('No Location Data'),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _getCurrentLocation,
        tooltip: 'Get Location',
        child: const Icon(Icons.add),
      ),
    );
  }
}

import 'package:flutter/material.dart';

class ExploreMorePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Implement the UI for the Report Issue page
    return Scaffold(
      appBar: AppBar(
        title: Text('Explore More'),
      ),
      body: Center(
        child: Text('This is the Explore More  Page'),
      ),
    );
  }
}

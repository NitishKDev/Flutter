import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';

// Data model for an issue
class Issue {
  final String id;
  final String title;
  final String description;
  final DateTime submissionDate;
  final String imageURL; // Added imageURL property
  int votes;
  bool hasVoted; // Added hasVoted property

  Issue({
    required this.id,
    required this.title,
    required this.description,
    required this.submissionDate,
    required this.imageURL,
    this.votes = 0,
    this.hasVoted = false,
  });
}

class RecentComplaintsPage extends StatefulWidget {
  @override
  _RecentComplaintsPageState createState() => _RecentComplaintsPageState();
}

class _RecentComplaintsPageState extends State<RecentComplaintsPage> {
  List<Issue> issues = [];
  final DatabaseReference databaseReference =
      FirebaseDatabase.instance.reference().child('issues');
  final FirebaseAuth _auth = FirebaseAuth.instance;

  @override
  void initState() {
    super.initState();
    databaseReference.onChildAdded.listen((event) {
      Map<dynamic, dynamic> values =
          Map.from(event.snapshot.value as Map); // Fix casting issue
      Issue newIssue = Issue(
        id: event.snapshot.key!,
        title: values['issuerName'],
        description: values['description'],
        submissionDate: DateTime.now(),
        imageURL: values['imageURL'],
      );
      setState(() {
        issues.add(newIssue);
      });
    });
  }

  void _voteForIssue(Issue issue) async {
    User? user = _auth.currentUser;
    if (user != null && !issue.hasVoted) {
      setState(() {
        issue.votes++;
        issue.hasVoted = true;
      });

      await databaseReference.child(issue.id).update({
        'votes': issue.votes,
        'voters/${user.uid}': true,
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Voted for the issue (${issue.title})'),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('You have already voted for this issue'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Recent Complaints'),
      ),
      body: issues.isEmpty
          ? Center(
              child: Text('Database is empty'),
            )
          : ListView.builder(
              itemCount: issues.length,
              itemBuilder: (context, index) {
                final issue = issues[index];
                return Card(
                  margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                  child: ListTile(
                    title: Text(issue.title),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Submission Date: ${issue.submissionDate}'),
                        Text('Votes: ${issue.votes}'),
                        if (issue.imageURL.isNotEmpty)
                          Image.network(
                            issue.imageURL,
                            height: 100,
                            width: 100,
                            fit: BoxFit.cover,
                          ),
                      ],
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        ElevatedButton(
                          onPressed: () {
                            _voteForIssue(issue);
                          },
                          child: Text('Vote'),
                        ),
                        SizedBox(width: 8),
                        ElevatedButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) =>
                                    IssueDetailsPage(issue: issue),
                              ),
                            );
                          },
                          child: Text('Details'),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}

class IssueDetailsPage extends StatelessWidget {
  final Issue issue;

  IssueDetailsPage({required this.issue});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Issue Details'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Issue ID: ${issue.id}'),
            Text('Title: ${issue.title}'),
            Text('Description: ${issue.description}'),
            Text('Submission Date: ${issue.submissionDate}'),
            if (issue.imageURL.isNotEmpty)
              Image.network(
                issue.imageURL,
                height: 100,
                width: 100,
                fit: BoxFit.cover,
              ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                issue.votes++;
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Voted for the issue (${issue.title})'),
                  ),
                );
              },
              child: Text('Vote (${issue.votes})'),
            ),
          ],
        ),
      ),
    );
  }
}
